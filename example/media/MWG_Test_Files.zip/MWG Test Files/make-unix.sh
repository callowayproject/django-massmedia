mkdir output
cd output

mkdir 3_4_1_Keywords
cd 3_4_1_Keywords
../../bin/unix/TweakImage < ../../scripts/make_keywords.txt > ../log_keywords.txt
cd ..

mkdir 3_4_2_Description
cd 3_4_2_Description
../../bin/unix/TweakImage < ../../scripts/make_description.txt > ../log_description.txt
cd ..

mkdir 3_4_3_DateTime
cd 3_4_3_DateTime
../../bin/unix/TweakImage < ../../scripts/make_datetime.txt > ../log_datetime.txt
cd ..

mkdir 3_4_4_Orientation
cd 3_4_4_Orientation
../../bin/unix/TweakImage < ../../scripts/make_orientation.txt > ../log_orientation.txt
cd ..

mkdir 3_4_5_Rating
cd 3_4_5_Rating
../../bin/unix/TweakImage < ../../scripts/make_rating.txt > ../log_rating.txt
cd ..

mkdir 3_4_6_Copyright
cd 3_4_6_Copyright
../../bin/unix/TweakImage < ../../scripts/make_copyright.txt > ../log_copyright.txt
cd ..

mkdir 3_4_7_Creator
cd 3_4_7_Creator
../../bin/unix/TweakImage < ../../scripts/make_creator.txt > ../log_creator.txt
cd ..

cd ..
