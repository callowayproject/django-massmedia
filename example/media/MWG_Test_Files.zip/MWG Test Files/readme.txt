Metadata Working Group Test Files

When the Metadata Working Group Guidelines were published, the 
ability to verify that an application consumed files according 
to the guidance was left as an exercise to the readers and 
implementors.  Though we tried to make the guidance clear, as 
with any specification different readers may interpret the 
intentions of the authors slightly differently.  In order to 
prevent mis-interpretation, the Metadata Working Group decided 
that sharing a set of test files would provide readers and 
implementors the tools necessary to verify that the guidance 
for reading metadata in each section was implemented correctly 
by their product.

There is also an Excel spreadsheet (saved as PDF as well) that
outlines the naming convention of the files and acts as a guide
to the files.  Using this, along with the test files, readers 
and implementors can know what metadata to expect.

The tools consist of:

 - DumpImage: command line tool to dump all of the metadata in
              an input file

 - TweakImage: command line tool to alter the metadata in an 
               input file based on the guidance

 - Sample Files: output of TweakImage on a sample file when
                 each guidance was written

 - Source: source for both DumpImage and TweakImage

To build DumpImage or TweakImage:
- Acquire the Adobe XMP Toolkit SDK.
- Copy the XMP build, public, source, and third-party folders
  to the MWG projects/XMPToolkit folder.
- Follow the XMP instructions to acquire Expat, build XMPCore.
- Use the MWG mac, win, or unix project to build the tool.
